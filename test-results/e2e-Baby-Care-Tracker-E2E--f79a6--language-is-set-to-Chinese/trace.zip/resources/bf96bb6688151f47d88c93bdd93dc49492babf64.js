const translations = {
    'en': {
        // Navigation
        'nav_dashboard': 'Dashboard',
        'nav_statistics': 'Statistics',
        'nav_settings': 'Settings',
        
        // Date Navigation
        'previous_day': 'Previous Day',
        'next_day': 'Next Day',
        'today': 'Today',
        
        // Care Records
        'care_records': 'Care Records',
        'add_record': 'Add New Record',
        'delete_selected': 'Delete Selected',
        'time': 'Time',
        'care_type': 'Care Type',
        'details': 'Details',
        'notes': 'Notes',
        'date': 'Date',
        
        // Care Types
        'formula': 'Formula Feeding',
        'breastfeeding': 'Breastfeeding',
        'diaper': 'Diaper Change',
        'select_care_type': 'Select care type',
        
        // Form Fields
        'volume': 'Volume (ml)',
        'duration': 'Duration (minutes)',
        'diaper_type': 'Diaper Type',
        'pee': 'Pee',
        'poo': 'Poo',
        'both': 'Both',
        'add_record_btn': 'Add Record',
        'minutes': 'min',
        'ml': 'ml',
        
        // Theme
        'dark_mode': 'Dark mode',
        'light_mode': 'Light mode',
        
        // Settings
        'language': 'Language',
        'theme': 'Theme',
        'timezone': 'Timezone',
        
        // Messages
        'record_added': 'Record added successfully',
        'record_deleted': 'Record deleted successfully',
        'error_occurred': 'An error occurred',
        'no_records': 'No records found for this date',
        'loading': 'Loading...',
        'future_date': 'Cannot select future dates',
        'no_records_found_for_this_date': 'No records found for this date',
        
        // Settings
        'settings_title': 'Settings',
        
        // Languages
        'english': 'English',
        'chinese': 'Simplified Chinese',
        
        // Other UI elements
        'toggle_theme': 'Toggle theme',
        'baby_care': 'Baby Care',
        'volume_ml': 'Volume (ml)',
        'duration_min': 'Duration (minutes)',
        'monday': 'Monday',
        'tuesday': 'Tuesday',
        'wednesday': 'Wednesday',
        'thursday': 'Thursday',
        'friday': 'Friday',
        'saturday': 'Saturday',
        'sunday': 'Sunday',
        'january': 'January',
        'february': 'February',
        'march': 'March',
        'april': 'April',
        'may': 'May',
        'june': 'June',
        'july': 'July',
        'august': 'August',
        'september': 'September',
        'october': 'October',
        'november': 'November',
        'december': 'December',
        'year': 'Year',
        'month': 'Month',
        'day': 'Day',
        
        // Notifications and Messages
        'record_added_successfully': 'Record added successfully',
        'records_deleted_successfully': 'Records deleted successfully',
        'failed_to_add_record': 'Failed to add record',
        'failed_to_delete_records': 'Failed to delete records',
        'no_records_selected': 'No records selected',
        'are_you_sure_you_want_to_delete_selected_records': 'Are you sure you want to delete selected records?',
        'server_connection_error': 'Server connection error',
        'an_error_occurred': 'An error occurred',
        'cannot_select_future_dates': 'Cannot select future dates',
        'failed_to_change_date': 'Failed to change date',
        'switched_to': 'Switched to',
        'mode': 'mode',
        
        // Weekdays (lowercase for date formatting)
        'monday': 'Monday',
        'tuesday': 'Tuesday',
        'wednesday': 'Wednesday',
        'thursday': 'Thursday',
        'friday': 'Friday',
        'saturday': 'Saturday',
        'sunday': 'Sunday'
    },
    'zh-CN': {
        // Navigation
        'nav_dashboard': '仪表板',
        'nav_statistics': '统计',
        'nav_settings': '设置',
        
        // Date Navigation
        'previous_day': '前一天',
        'next_day': '后一天',
        'today': '今天',
        
        // Care Records
        'care_records': '护理记录',
        'add_record': '添加新记录',
        'delete_selected': '删除所选',
        'time': '时间',
        'care_type': '护理类型',
        'details': '详情',
        'notes': '备注',
        'date': '日期',
        
        // Care Types
        'formula': '配方奶',
        'breastfeeding': '母乳喂养',
        'diaper': '换尿布',
        'select_care_type': '选择护理类型',
        
        // Form Fields
        'volume': '容量 (ml)',
        'duration': '时长 (分钟)',
        'diaper_type': '尿布类型',
        'pee': '小便',
        'poo': '大便',
        'both': '都有',
        'add_record_btn': '添加记录',
        'minutes': '分钟',
        'ml': '毫升',
        
        // Theme
        'dark_mode': '深色模式',
        'light_mode': '浅色模式',
        
        // Settings
        'language': '语言',
        'theme': '主题',
        'timezone': '时区',
        
        // Messages
        'record_added': '记录添加成功',
        'record_deleted': '记录删除成功',
        'error_occurred': '发生错误',
        'no_records': '该日期没有记录',
        'loading': '加载中...',
        'future_date': '不能选择未来日期',
        'no_records_found_for_this_date': '该日期没有记录',
        
        // Settings
        'settings_title': '设置',
        
        // Languages
        'english': '英语',
        'chinese': '简体中文',
        
        // Other UI elements
        'toggle_theme': '切换主题',
        'baby_care': '婴儿护理',
        'volume_ml': '容量 (毫升)',
        'duration_min': '时长 (分钟)',
        'monday': '星期一',
        'tuesday': '星期二',
        'wednesday': '星期三',
        'thursday': '星期四',
        'friday': '星期五',
        'saturday': '星期六',
        'sunday': '星期日',
        'january': '一月',
        'february': '二月',
        'march': '三月',
        'april': '四月',
        'may': '五月',
        'june': '六月',
        'july': '七月',
        'august': '八月',
        'september': '九月',
        'october': '十月',
        'november': '十一月',
        'december': '十二月',
        'year': '年',
        'month': '月',
        'day': '日',
        
        // Notifications and Messages
        'record_added_successfully': '记录添加成功',
        'records_deleted_successfully': '记录删除成功',
        'failed_to_add_record': '添加记录失败',
        'failed_to_delete_records': '删除记录失败',
        'no_records_selected': '未选择任何记录',
        'are_you_sure_you_want_to_delete_selected_records': '确定要删除所选记录吗？',
        'server_connection_error': '服务器连接错误',
        'an_error_occurred': '发生错误',
        'cannot_select_future_dates': '不能选择未来日期',
        'failed_to_change_date': '更改日期失败',
        'switched_to': '已切换至',
        'mode': '模式',
        
        // Weekdays (lowercase for date formatting)
        'monday': '星期一',
        'tuesday': '星期二',
        'wednesday': '星期三',
        'thursday': '星期四',
        'friday': '星期五',
        'saturday': '星期六',
        'sunday': '星期日'
    }
};

// Language utilities
const i18n = {
    currentLocale: 'en',
    
    init() {
        this.currentLocale = localStorage.getItem('language') || 'en';
        document.documentElement.setAttribute('lang', this.currentLocale);
        this.updatePageContent();
    },
    
    setLocale(locale) {
        if (translations[locale]) {
            this.currentLocale = locale;
            localStorage.setItem('language', locale);
            document.documentElement.setAttribute('lang', locale);
            this.updatePageContent();
        }
    },
    
    t(key) {
        return translations[this.currentLocale]?.[key] || translations['en'][key] || key;
    },
    
    formatDate(date) {
        if (this.currentLocale === 'zh-CN') {
            const year = date.getFullYear();
            const month = date.getMonth() + 1;
            const day = date.getDate();
            
            // Get weekday (0 = Sunday, 1 = Monday, etc.)
            const weekdayNum = date.getDay();
            // Map weekday number to translation key
            const weekdayKeys = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
            const weekday = this.t(weekdayKeys[weekdayNum]);
            
            return `${year}${this.t('year')}${month}${this.t('month')}${day}${this.t('day')}，${weekday}`;
        }
        
        return date.toLocaleDateString(this.currentLocale, {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            timeZone: TIME_ZONE
        });
    },
    
    updatePageContent() {
        // Update all elements with data-i18n attribute
        document.querySelectorAll('[data-i18n]').forEach(element => {
            const key = element.getAttribute('data-i18n');
            if (key) {
                if (element.tagName === 'INPUT' && element.getAttribute('placeholder')) {
                    element.placeholder = this.t(key);
                } else {
                    element.textContent = this.t(key);
                }
            }
        });
        
        // Update date display format based on locale
        const dateDisplay = document.getElementById('currentDateDisplay');
        if (dateDisplay && window.currentDate) {
            const currentDate = new Date(window.currentDate + 'T00:00:00');
            dateDisplay.textContent = this.formatDate(currentDate);
        }

        // Update all elements with data-i18n-title attribute
        document.querySelectorAll('[data-i18n-title]').forEach(element => {
            const key = element.getAttribute('data-i18n-title');
            if (key) {
                element.title = this.t(key);
            }
        });

        // Update theme switch text
        const themeSwitch = document.querySelector('.theme-switch span');
        if (themeSwitch) {
            const currentTheme = document.documentElement.getAttribute('data-theme');
            themeSwitch.textContent = this.t(currentTheme === 'dark' ? 'dark_mode' : 'light_mode');
        }

        // Update form labels
        const volumeLabel = document.querySelector('label[for="volume"]');
        if (volumeLabel) {
            volumeLabel.textContent = this.t('volume_ml');
        }

        const durationLabel = document.querySelector('label[for="duration"]');
        if (durationLabel) {
            durationLabel.textContent = this.t('duration_min');
        }

        // Update table headers
        document.querySelectorAll('th[data-i18n]').forEach(header => {
            const key = header.getAttribute('data-i18n');
            header.textContent = this.t(key);
        });

        // Update logo text
        const logoText = document.querySelector('.sidebar-logo h2');
        if (logoText) {
            logoText.textContent = this.t('baby_care');
        }
    }
};

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { translations, i18n };
} 